<?php include('includes/config.php'); ?>
<?php include('include/header.php'); ?>
<?php include('include/navbar.php'); ?>
<?php include('components/hero.php'); ?>
<?php include('components/joblist.php'); ?>
<?php include('include/footer.php'); ?>   