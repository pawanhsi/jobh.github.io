<?php
defined('DS') ? null : define('DS','/');
defined('BASE_PATH') ? null : define('BASE_PATH','http://localhost:8080/uaehrm'.DS);
?>