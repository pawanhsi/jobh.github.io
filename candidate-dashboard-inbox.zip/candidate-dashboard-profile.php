<?php include('includes/config.php'); ?>
<?php include('include/header.php'); ?>

<div class="pxp-dashboard-side-panel d-none d-lg-block">
    <div class="pxp-logo">
        <a href="index.php" class="pxp-animate"><span style="color: var(--pxpMainColor)">j</span>obster</a>
    </div>

    <nav class="mt-3 mt-lg-4 d-flex justify-content-between flex-column pb-100">
        <div class="pxp-dashboard-side-label">Admin tools</div>
        <ul class="list-unstyled">
            <li><a href="candidate-dashboard.php"><span class="fa fa-home"></span>Dashboard</a></li>
            <li class="pxp-active"><a href="candidate-dashboard-profile.php"><span class="fa fa-pencil"></span>Edit Profile</a></li>
            <li><a href="candidate-dashboard-applications.php"><span class="fa fa-file-text-o"></span>Apllications</a></li>
            <li><a href="candidate-dashboard-fav-jobs.php"><span class="fa fa-heart-o"></span>Favourite Jobs</a></li>
            <li><a href="candidate-dashboard-password.php"><span class="fa fa-lock"></span>Change Password</a></li>
        </ul>
        <div class="pxp-dashboard-side-label mt-3 mt-lg-4">Insights</div>
        <ul class="list-unstyled">
            <li>
                <a href="candidate-dashboard-inbox.php" class="d-flex justify-content-between align-items-center">
                    <div><span class="fa fa-envelope-o"></span>Inbox</div>
                    <span class="badge rounded-pill">14</span>
                </a>
            </li>
            <li>
                <a href="candidate-dashboard-notifications.php" class="d-flex justify-content-between align-items-center">
                    <div><span class="fa fa-bell-o"></span>Notifications</div>
                    <span class="badge rounded-pill">5</span>
                </a>
            </li>
        </ul>
    </nav>

    <nav class="pxp-dashboard-side-user-nav-container pxp-is-candidate">
        <div class="pxp-dashboard-side-user-nav">
            <div class="dropdown pxp-dashboard-side-user-nav-dropdown dropup">
                <a role="button" class="dropdown-toggle" data-bs-toggle="dropdown">
                    <div class="pxp-dashboard-side-user-nav-avatar pxp-cover" style="background-image: url(assets/images/avatar-1.jpg);"></div>
                    <div class="pxp-dashboard-side-user-nav-name">Derek Cotner</div>
                </a>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="candidate-dashboard.php">Dashboard</a></li>
                    <li><a class="dropdown-item" href="candidate-dashboard-profile.php">Edit profile</a></li>
                    <li><a class="dropdown-item" href="index.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>
</div>
<div class="pxp-dashboard-content">
    <div class="pxp-dashboard-content-header pxp-is-candidate">
        <div class="pxp-nav-trigger navbar pxp-is-dashboard d-lg-none">
            <a role="button" data-bs-toggle="offcanvas" data-bs-target="#pxpMobileNav" aria-controls="pxpMobileNav">
                <div class="pxp-line-1"></div>
                <div class="pxp-line-2"></div>
                <div class="pxp-line-3"></div>
            </a>
            <div class="offcanvas offcanvas-start pxp-nav-mobile-container pxp-is-dashboard pxp-is-candidate" tabindex="-1" id="pxpMobileNav">
                <div class="offcanvas-header">
                    <div class="pxp-logo">
                        <a href="index.php" class="pxp-animate"><span style="color: var(--pxpMainColor)">j</span>obster</a>
                    </div>
                    <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>
                <div class="offcanvas-body">
                    <nav class="pxp-nav-mobile">
                        <ul class="navbar-nav justify-content-end flex-grow-1">
                            <li class="pxp-dropdown-header">Admin tools</li>
                            <li class="nav-item"><a href="candidate-dashboard.php"><span class="fa fa-home"></span>Dashboard</a></li>
                            <li class="nav-item"><a href="candidate-dashboard-profile.php"><span class="fa fa-pencil"></span>Edit Profile</a></li>
                            <li class="nav-item"><a href="candidate-dashboard-applications.php"><span class="fa fa-file-text-o"></span>Apllications</a></li>
                            <li class="nav-item"><a href="candidate-dashboard-fav-jobs.php"><span class="fa fa-heart-o"></span>Favourite Jobs</a></li>
                            <li class="nav-item"><a href="candidate-dashboard-password.php"><span class="fa fa-lock"></span>Change Password</a></li>
                            <li class="pxp-dropdown-header mt-4">Insights</li>
                            <li class="nav-item">
                                <a href="candidate-dashboard-inbox.php" class="d-flex justify-content-between align-items-center">
                                    <div><span class="fa fa-envelope-o"></span>Inbox</div>
                                    <span class="badge rounded-pill">14</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="candidate-dashboard-notifications.php" class="d-flex justify-content-between align-items-center">
                                    <div><span class="fa fa-bell-o"></span>Notifications</div>
                                    <span class="badge rounded-pill">5</span>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <nav class="pxp-user-nav pxp-on-light">
            <div class="dropdown pxp-user-nav-dropdown pxp-user-notifications">
                <a role="button" class="dropdown-toggle" data-bs-toggle="dropdown">
                    <span class="fa fa-bell-o"></span>
                    <div class="pxp-user-notifications-counter">5</div>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="candidate-dashboard-notifications.php"><strong>Artistre Studio</strong> viewed your profile. <span class="pxp-is-time">20m</span></a></li>
                    <li><a class="dropdown-item" href="candidate-dashboard-notifications.php"><strong>CoderBotics</strong> sent you a message. <span class="pxp-is-time">1h</span></a></li>
                    <li><a class="dropdown-item" href="candidate-dashboard-notifications.php"><strong>Illuminate Studio</strong> viewed your profile. <span class="pxp-is-time">2h</span></a></li>
                    <li><a class="dropdown-item" href="candidate-dashboard-notifications.php"><strong>Syspresoft</strong> sent you a message. <span class="pxp-is-time">5h</span></a></li>
                    <li><a class="dropdown-item" href="candidate-dashboard-notifications.php"><strong>Artistre Studio</strong> viewed your profile. <span class="pxp-is-time">1d</span></a></li>
                    <li><a class="dropdown-item" href="candidate-dashboard-notifications.php"><strong>Illuminate Studio</strong> viewed your profile. <span class="pxp-is-time">3d</span></a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item pxp-link" href="candidate-dashboard-notifications.php">Read All</a></li>
                </ul>
            </div>
            <div class="dropdown pxp-user-nav-dropdown">
                <a role="button" class="dropdown-toggle" data-bs-toggle="dropdown">
                    <div class="pxp-user-nav-avatar pxp-cover" style="background-image: url(assets/images/avatar-1.jpg);"></div>
                    <div class="pxp-user-nav-name d-none d-md-block">Derek Cotner</div>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="candidate-dashboard.php">Dashboard</a></li>
                    <li><a class="dropdown-item" href="candidate-dashboard-profile.php">Edit profile</a></li>
                    <li><a class="dropdown-item" href="index.php">Logout</a></li>
                </ul>
            </div>
        </nav>
    </div>

    <div class="pxp-dashboard-content-details">
        <h1>Edit Profile</h1>
        <p class="pxp-text-light">Edit your candidate profile page info.</p>

        <form>
            <div class="row mt-4 mt-lg-5">
                <div class="col-xxl-8">
                    <div class="mb-3">
                        <label for="pxp-candidate-name" class="form-label">Name</label>
                        <input type="text" id="pxp-candidate-name" class="form-control" placeholder="Add your name">
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="mb-3">
                                <label for="pxp-candidate-title" class="form-label">Title</label>
                                <input type="text" id="pxp-candidate-title" class="form-control" placeholder="E.g. Web Designer">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="mb-3">
                                <label for="pxp-candidate-location" class="form-label">Location</label>
                                <input type="tel" id="pxp-candidate-location" class="form-control" placeholder="E.g. San Francisco, CA">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="mb-3">
                                <label for="pxp-candidate-email" class="form-label">Email</label>
                                <input type="email" id="pxp-candidate-email" class="form-control" placeholder="candidate@email.com">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="mb-3">
                                <label for="pxp-candidate-phone" class="form-label">Phone</label>
                                <input type="tel" id="pxp-candidate-phone" class="form-control" placeholder="(+12) 345 6789">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xxl-4">
                    <div class="form-label">&nbsp;</div>
                    <div class="pxp-candidate-cover mb-3">
                        <input type="file" id="pxp-candidate-cover-choose-file" accept="image/*">
                        <label for="pxp-candidate-cover-choose-file" class="pxp-cover"><span>Upload Cover Image</span></label>
                    </div>
                    <div class="pxp-candidate-photo mb-3">
                        <input type="file" id="pxp-candidate-photo-choose-file" accept="image/*">
                        <label for="pxp-candidate-photo-choose-file" class="pxp-cover"><span>Upload<br>Photo</span></label>
                    </div>
                </div>
            </div>

            <div class="mb-3">
                <label for="pxp-candidate-about" class="form-label">About you</label>
                <textarea class="form-control" id="pxp-candidate-about" placeholder="Type your info here..."></textarea>
            </div>

            <div class="mt-4 mt-lg-5">
                <h2>Skills</h2>
                <div class="pxp-candidate-dashboard-skills mb-3">
                    <ul class="list-unstyled">
                        <li>Work from home<span class="fa fa-trash-o"></span></li>
                        <li>Part-time<span class="fa fa-trash-o"></span></li>
                        <li>Administration<span class="fa fa-trash-o"></span></li>
                        <li>Finance<span class="fa fa-trash-o"></span></li>
                        <li>Retail<span class="fa fa-trash-o"></span></li>
                        <li>IT<span class="fa fa-trash-o"></span></li>
                        <li>Engineering<span class="fa fa-trash-o"></span></li>
                        <li>Sales<span class="fa fa-trash-o"></span></li>
                        <li>Manufacturing<span class="fa fa-trash-o"></span></li>
                    </ul>
                </div>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" placeholder="Skill">
                    <button class="btn">Add Skill</button>
                </div>
            </div>

            <div class="mt-4 mt-lg-5">
                <h2>Work Experience</h2>
                <div class="table-responsive">
                    <table class="table align-middle">
                        <tr>
                            <td style="width: 30%;"><div class="pxp-candidate-dashboard-experience-title">Senior UI/UX Designer</div></td>
                            <td style="width: 25%;"><div class="pxp-candidate-dashboard-experience-company">Adobe Corporation</div></td>
                            <td style="width: 25%;"><div class="pxp-candidate-dashboard-experience-time">2005 - 2013</div></td>
                            <td>
                                <div class="pxp-dashboard-table-options">
                                    <ul class="list-unstyled">
                                        <li><button title="Edit"><span class="fa fa-pencil"></span></button></li>
                                        <li><button title="Delete"><span class="fa fa-trash-o"></span></button></li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 30%;"><div class="pxp-candidate-dashboard-experience-title">Senior UI/UX Designer</div></td>
                            <td style="width: 25%;"><div class="pxp-candidate-dashboard-experience-company">Adobe Corporation</div></td>
                            <td style="width: 25%;"><div class="pxp-candidate-dashboard-experience-time">2005 - 2013</div></td>
                            <td>
                                <div class="pxp-dashboard-table-options">
                                    <ul class="list-unstyled">
                                        <li><button title="Edit"><span class="fa fa-pencil"></span></button></li>
                                        <li><button title="Delete"><span class="fa fa-trash-o"></span></button></li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 30%;"><div class="pxp-candidate-dashboard-experience-title">Senior UI/UX Designer</div></td>
                            <td style="width: 25%;"><div class="pxp-candidate-dashboard-experience-company">Adobe Corporation</div></td>
                            <td style="width: 25%;"><div class="pxp-candidate-dashboard-experience-time">2005 - 2013</div></td>
                            <td>
                                <div class="pxp-dashboard-table-options">
                                    <ul class="list-unstyled">
                                        <li><button title="Edit"><span class="fa fa-pencil"></span></button></li>
                                        <li><button title="Delete"><span class="fa fa-trash-o"></span></button></li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                    </table>
                </div>

                <div class="row mt-3 mt-lg-4">
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label for="pxp-candidate-work-title" class="form-label">Job title</label>
                            <input type="text" id="pxp-candidate-work-title" class="form-control" placeholder="E.g. Web Designer">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label for="pxp-candidate-work-company" class="form-label">Company</label>
                            <input type="text" id="pxp-candidate-work-company" class="form-control" placeholder="Company name">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label for="pxp-candidate-work-time" class="form-label">Time period</label>
                            <input type="text" id="pxp-candidate-work-time" class="form-control" placeholder="E.g. 2005 - 2013">
                        </div>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="pxp-candidate-work-about" class="form-label">Description</label>
                    <textarea class="form-control pxp-smaller" id="pxp-candidate-work-about" placeholder="Type a short description here..."></textarea>
                </div>
                <button class="btn rounded-pill pxp-subsection-cta">Add Experience</button>
            </div>

            <div class="mt-4 mt-lg-5">
                <h2>Education & Training</h2>
                <div class="table-responsive">
                    <table class="table align-middle">
                        <tr>
                            <td style="width: 30%;"><div class="pxp-candidate-dashboard-experience-title">Architecure</div></td>
                            <td style="width: 25%;"><div class="pxp-candidate-dashboard-experience-school">Politehnica University of Timisoara: Bachelor of Architecture</div></td>
                            <td style="width: 25%;"><div class="pxp-candidate-dashboard-experience-time">2011 - 2017</div></td>
                            <td>
                                <div class="pxp-dashboard-table-options">
                                    <ul class="list-unstyled">
                                        <li><button title="Edit"><span class="fa fa-pencil"></span></button></li>
                                        <li><button title="Delete"><span class="fa fa-trash-o"></span></button></li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 30%;"><div class="pxp-candidate-dashboard-experience-title">Front End Web Developer</div></td>
                            <td style="width: 25%;"><div class="pxp-candidate-dashboard-experience-school">Udacity Nanodegree Program</div></td>
                            <td style="width: 25%;"><div class="pxp-candidate-dashboard-experience-time">2020 - 2020</div></td>
                            <td>
                                <div class="pxp-dashboard-table-options">
                                    <ul class="list-unstyled">
                                        <li><button title="Edit"><span class="fa fa-pencil"></span></button></li>
                                        <li><button title="Delete"><span class="fa fa-trash-o"></span></button></li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 30%;"><div class="pxp-candidate-dashboard-experience-title">Build Responsive Real World Websites with HTML5 and CSS3</div></td>
                            <td style="width: 25%;"><div class="pxp-candidate-dashboard-experience-company">Udemy</div></td>
                            <td style="width: 25%;"><div class="pxp-candidate-dashboard-experience-time">2021 - 2021</div></td>
                            <td>
                                <div class="pxp-dashboard-table-options">
                                    <ul class="list-unstyled">
                                        <li><button title="Edit"><span class="fa fa-pencil"></span></button></li>
                                        <li><button title="Delete"><span class="fa fa-trash-o"></span></button></li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                    </table>
                </div>

                <div class="row mt-3 mt-lg-4">
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label for="pxp-candidate-edu-title" class="form-label">Title</label>
                            <input type="text" id="pxp-candidate-edu-title" class="form-control" placeholder="E.g. Architecure">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label for="pxp-candidate-edu-school" class="form-label">School</label>
                            <input type="text" id="pxp-candidate-edu-school" class="form-control" placeholder="School name">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label for="pxp-candidate-edu-time" class="form-label">Time period</label>
                            <input type="text" id="pxp-candidate-edu-time" class="form-control" placeholder="E.g. 2005 - 2013">
                        </div>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="pxp-candidate-edu-about" class="form-label">Description</label>
                    <textarea class="form-control pxp-smaller" id="pxp-candidate-edu-about" placeholder="Type a short description here..."></textarea>
                </div>
                <button class="btn rounded-pill pxp-subsection-cta">Add Education</button>
            </div>

            <div class="mt-4 mt-lg-5">
                <button class="btn rounded-pill pxp-section-cta">Save Profile</button>
            </div>
        </form>
    </div>
    <?php include('include/footer.php'); ?>